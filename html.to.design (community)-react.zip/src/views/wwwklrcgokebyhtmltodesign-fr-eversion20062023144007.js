import React from 'react'

import { Helmet } from 'react-helmet'

import './wwwklrcgokebyhtmltodesign-fr-eversion20062023144007.css'

const WwwklrcgokebyhtmltodesignFREEversion20062023144007 = (props) => {
  return (
    <div className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-container">
      <Helmet>
        <title>exported project</title>
      </Helmet>
      <div className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-wwwklrcgokebyhtmltodesign-fr-eversion20062023144007">
        <div className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-iframe"></div>
        <div className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-divt3wrapper">
          <div className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-divjbtopbar">
            <div className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-divrow">
              <div className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-list">
                <span className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-text">
                  <span>Contact Us</span>
                </span>
                <span className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-text002">
                  <span>Staff Login</span>
                </span>
                <span className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-text004">
                  <span>Tenders</span>
                </span>
                <span className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-text006">
                  <span>Site Map</span>
                </span>
                <span className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-text008">
                  <span>FAQs</span>
                </span>
                <span className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-text010">
                  <span>Laws of Kenya</span>
                </span>
                <span className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-text012">
                  <span>Vacancies</span>
                </span>
              </div>
              <div className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-list1">
                <img
                  alt="ItemLink172"
                  src="/external/itemlink172-wt69.svg"
                  className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-item-link"
                />
                <img
                  alt="ItemLink174"
                  src="/external/itemlink174-zgri.svg"
                  className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-item-link01"
                />
                <img
                  alt="ItemLink176"
                  src="/external/itemlink176-alpk.svg"
                  className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-item-link02"
                />
              </div>
            </div>
          </div>
          <div className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-header">
            <div className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-linkklrclogoversion4png"></div>
            <div className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-divcustom">
              <div className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-divstyle2">
                <img
                  alt="Icon182"
                  src="/external/icon182-8aja.svg"
                  className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-icon"
                />
                <div className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-divh2d612c7e35">
                  <span className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-text014">
                    <span>Opening Hours :</span>
                  </span>
                  <span className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-text016">
                    <span>Mon - Fri: 8am - 5pm</span>
                  </span>
                </div>
                <img
                  alt="Icon187"
                  src="/external/icon187-lubn.svg"
                  className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-icon01"
                />
                <div className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-divh2d9547cb60">
                  <span className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-text018">
                    <span>Send us a Mail:</span>
                  </span>
                  <span className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-text020">
                    <span>info@klrc.go.ke</span>
                  </span>
                </div>
              </div>
            </div>
          </div>
          <div className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-nav">
            <div className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-divcontainer">
              <button className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-button">
                <img
                  alt="spanbarfirst195"
                  src="/external/spanbarfirst195-scjq-200h.png"
                  className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-spanbarfirst"
                />
                <img
                  alt="spanbarmid196"
                  src="/external/spanbarmid196-itu-200h.png"
                  className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-spanbarmid"
                />
                <img
                  alt="spanbarlast197"
                  src="/external/spanbarlast197-kj-200h.png"
                  className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-spanbarlast"
                />
              </button>
              <div className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-list2">
                <span className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-text022">
                  <span>Home</span>
                </span>
                <div className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-item-link03">
                  <span className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-text024">
                    <span>
                      About Us
                      <span
                        dangerouslySetInnerHTML={{
                          __html: ' ',
                        }}
                      />
                    </span>
                  </span>
                  <img
                    alt="Icon1102"
                    src="/external/icon1102-bktr.svg"
                    className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-icon02"
                  />
                </div>
                <div className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-item-link04">
                  <span className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-text026">
                    <span>
                      Management
                      <span
                        dangerouslySetInnerHTML={{
                          __html: ' ',
                        }}
                      />
                    </span>
                  </span>
                  <img
                    alt="Icon1106"
                    src="/external/icon1106-679.svg"
                    className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-icon03"
                  />
                </div>
                <div className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-item-link05">
                  <span className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-text028">
                    <span>
                      Bills
                      <span
                        dangerouslySetInnerHTML={{
                          __html: ' ',
                        }}
                      />
                    </span>
                  </span>
                  <img
                    alt="Icon1110"
                    src="/external/icon1110-uxb.svg"
                    className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-icon04"
                  />
                </div>
                <div className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-item-link06">
                  <span className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-text030">
                    <span>
                      Media Center
                      <span
                        dangerouslySetInnerHTML={{
                          __html: ' ',
                        }}
                      />
                    </span>
                  </span>
                  <img
                    alt="Icon1114"
                    src="/external/icon1114-mk69.svg"
                    className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-icon05"
                  />
                </div>
                <span className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-text032">
                  <span>KLRC Blog</span>
                </span>
                <div className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-item-link07">
                  <span className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-text034">
                    <span>Projects</span>
                  </span>
                  <img
                    alt="Icon1119"
                    src="/external/icon1119-c4ni.svg"
                    className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-icon06"
                  />
                </div>
                <div className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-item-link08">
                  <span className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-text036">
                    <span>
                      Mandate
                      <span
                        dangerouslySetInnerHTML={{
                          __html: ' ',
                        }}
                      />
                    </span>
                  </span>
                  <img
                    alt="Icon1123"
                    src="/external/icon1123-rkisf.svg"
                    className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-icon07"
                  />
                </div>
                <span className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-text038">
                  <span>Publications</span>
                </span>
              </div>
            </div>
          </div>
          <div className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-nav1">
            <div className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-divcolmd12">
              <div className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-hgroup-heading1">
                <span className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-text040">
                  <span>
                    n0.2091. PRESIDENTIAL RESOLUTION OF THE STATE OF KENYA
                    DECLARING A STATE OF EMERGENCY BECAUSE OF THE MULTIPLE
                    TERRORISTS’ ATTACKS
                  </span>
                </span>
              </div>
              <div className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-divjbnavhealper">
                <div className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-klrclogoversion4apng"></div>
              </div>
            </div>
          </div>
          <div className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-divrow1">
            <div className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-divt3content">
              <div className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-divpageheader">
                <span className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-text042">
                  <span>Kenyan Resolution N0.2091</span>
                </span>
              </div>
              <div className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-aside-descriptions">
                <div className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-details">
                  <img
                    alt="Icon1140"
                    src="/external/icon1140-yh8.svg"
                    className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-icon08"
                  />
                  <span className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-text044">
                    <span>Chapter Nine - The Executive</span>
                  </span>
                </div>
                <div className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-details1">
                  <img
                    alt="Icon1144"
                    src="/external/icon1144-aik.svg"
                    className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-icon09"
                  />
                  <span className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-text046">
                    <span>Part 2. The President and Deputy President</span>
                  </span>
                </div>
                <div className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-details2">
                  <img
                    alt="Icon1148"
                    src="/external/icon1148-4evh.svg"
                    className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-icon10"
                  />
                  <span className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-text048">
                    <span>Hits: 127836</span>
                  </span>
                </div>
              </div>
              <div className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-article">
                <div className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-section">
                  <div className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-ph2d1479fda0">
                    <span className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-text050">
                      <span className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-text051">
                        <span>
                          CONSIDERING, the attacks in recent hours on the NBO
                          airport, an essential element of our strategic
                          infrastructure, as well as the closure of these.
                        </span>
                        <br></br>
                        <span></span>
                        <br></br>
                        <span>
                          CONSIDERING, that multiple terrorist attacks took
                          place in different geographical areas of the country,
                          mainly in strategic locations for both the economy and
                          the governance of the country
                        </span>
                        <br></br>
                        <span></span>
                        <br></br>
                        <span>
                          CONSIDERING, that the situation is now of a national
                          nature and is endangering the country&apos;s democracy
                          and the protection of our citizens
                        </span>
                        <br></br>
                        <span></span>
                        <br></br>
                        <span>
                          CONSIDERING, that the proliferation of these attacks
                          would affect the stability of our institutions in the
                          long term.
                        </span>
                        <br></br>
                        <span></span>
                        <br></br>
                        <span>
                          CONSIDERING, that the bordering countries confirm that
                          this terrorist initiative has a purely and simply
                          belligerent purpose and that the goal is the total
                          control of the country.
                        </span>
                        <br></br>
                        <span></span>
                        <br></br>
                        <span>
                          CONSIDERING, that such a threat requires rapid and
                          global action in order to be contained.
                        </span>
                        <br></br>
                        <span></span>
                        <br></br>
                        <span>
                          CONSIDERING, that such a threat requires a rapid,
                          global and strong action in order to be mastered.
                        </span>
                        <br></br>
                        <span></span>
                        <br></br>
                        <span></span>
                      </span>
                      <span className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-text081">
                        <span></span>
                        <br></br>
                        <span></span>
                      </span>
                      <span className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-text085">
                        <span>
                          NOW, THEREFORE, THE COUNTRY OF KENYA IN ITS GLOBALITY
                          RESOLVES AS FOLLOWS:
                        </span>
                        <br></br>
                        <span></span>
                        <br></br>
                        <span></span>
                      </span>
                      <span>
                        Section 1: The national State of Emergency declared to
                        exist throughout the country of Kenya pursuant to
                        Resolution N0. 2091
                      </span>
                    </span>
                  </div>
                </div>
              </div>
              <span className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-text092">
                <span>
                  {' '}
                  DECLARATION OF STATE OF EMERGENCY
                  <span
                    dangerouslySetInnerHTML={{
                      __html: ' ',
                    }}
                  />
                </span>
              </span>
            </div>
            <div className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-separator"></div>
            <div className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-divt3sidebar">
              <div className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-divmoduleinner">
                <span className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-text094">
                  <span>The Constitution of Kenya</span>
                </span>
                <div className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-list3">
                  <span className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-text096">
                    <span>Preamble</span>
                  </span>
                  <div className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-item-link09">
                    <span className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-text098">
                      <span>
                        <span>Chapter One - Sovereignty of the People and</span>
                        <br></br>
                        <span>Supremacy of this Constitution</span>
                      </span>
                    </span>
                  </div>
                  <span className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-text103">
                    <span>Chapter Two - The Republic</span>
                  </span>
                  <span className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-text105">
                    <span>Chapter Three - Citizenship</span>
                  </span>
                  <span className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-text107">
                    <span>Chapter Four - The Bill of Rights</span>
                  </span>
                  <span className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-text109">
                    <span>Chapter Five - Land and Environment</span>
                  </span>
                  <span className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-text111">
                    <span>Chapter Six - Leadership and Integrity</span>
                  </span>
                  <span className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-text113">
                    <span>Chapter Seven - Representation of the People</span>
                  </span>
                  <span className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-text115">
                    <span>Chapter Eight - The Legislature</span>
                  </span>
                  <span className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-text117">
                    <span>Chapter Nine - The Executive</span>
                  </span>
                  <span className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-text119">
                    <span>Chapter Ten - Judiciary</span>
                  </span>
                  <span className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-text121">
                    <span>Chapter Eleven - Devolved Government</span>
                  </span>
                  <span className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-text123">
                    <span>Chapter Twelve - Public Finance</span>
                  </span>
                  <span className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-text125">
                    <span>Chapter Thirteen - The Public Service</span>
                  </span>
                  <span className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-text127">
                    <span>Chapter Fourteen - National Security</span>
                  </span>
                  <div className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-item-link10">
                    <span className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-text129">
                      <span>
                        <span>
                          Chapter Fifteen - Commissions and Independent
                        </span>
                        <br></br>
                        <span>Offices</span>
                      </span>
                    </span>
                  </div>
                  <div className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-item-link11">
                    <span className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-text134">
                      <span>
                        <span>Chapter Sixteen - Amendment of this</span>
                        <br></br>
                        <span>Constitution</span>
                      </span>
                    </span>
                  </div>
                  <span className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-text139">
                    <span>Chapter Seventeen - General Provisions</span>
                  </span>
                  <div className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-item-link12">
                    <span className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-text141">
                      <span>
                        <span>Chapter Eighteen - Transitional and</span>
                        <br></br>
                        <span>Consequential Provisions</span>
                      </span>
                    </span>
                  </div>
                  <span className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-text146">
                    <span>Schedules - Schedules</span>
                  </span>
                </div>
              </div>
              <div className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-divmoduleinner1">
                <span className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-text148">
                  <span>Commissioners Charter</span>
                </span>
                <div className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-list4">
                  <span className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-text150">
                    <span>Article 1: Interpretation of Terms</span>
                  </span>
                  <span className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-text152">
                    <span>Article 10: Meetings</span>
                  </span>
                  <span className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-text154">
                    <span>Article 11: Commitment</span>
                  </span>
                  <span className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-text156">
                    <span>Article 12: Meetings by Technology</span>
                  </span>
                  <span className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-text158">
                    <span>Article 13: Committees of the Commission</span>
                  </span>
                  <span className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-text160">
                    <span>Article 14: Independence in Decision Making</span>
                  </span>
                  <span className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-text162">
                    <span>Article 15: Conflict of Interest</span>
                  </span>
                  <span className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-text164">
                    <span>Article 16: Confidentiality</span>
                  </span>
                  <span className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-text166">
                    <span>Article 17: Dissent by a Member</span>
                  </span>
                  <span className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-text168">
                    <span>Article 18: Induction and Capacity Development</span>
                  </span>
                  <span className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-text170">
                    <span>Article 19: Performance Evaluation</span>
                  </span>
                  <span className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-text172">
                    <span>Article 2: Background</span>
                  </span>
                  <span className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-text174">
                    <span>Article 20: Review of Charter</span>
                  </span>
                  <span className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-text176">
                    <span>Article 21: Commitment to the Charter</span>
                  </span>
                  <span className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-text178">
                    <span>Article 3: Objectives of the Charter</span>
                  </span>
                  <span className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-text180">
                    <span>Article 4: Conduct</span>
                  </span>
                  <span className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-text182">
                    <span>Article 5: Vision, Mission and Values</span>
                  </span>
                  <span className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-text184">
                    <span>Article 6: Scope of Responsibility</span>
                  </span>
                  <div className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-item-link13">
                    <span className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-text186">
                      <span>
                        <span>
                          Article 7: The Role and Responsibility of the
                        </span>
                        <br></br>
                        <span>Chairperson</span>
                      </span>
                    </span>
                  </div>
                  <div className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-item-link14">
                    <span className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-text191">
                      <span>
                        <span>Article 8: The Role and Responsibilities of</span>
                        <br></br>
                        <span>Commissioners</span>
                      </span>
                    </span>
                  </div>
                  <div className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-item-link15">
                    <span className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-text196">
                      <span>
                        <span>
                          Article 9: The Role and Responsibilities of the
                        </span>
                        <br></br>
                        <span>Commission Secretary</span>
                      </span>
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-footer">
            <div className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-divt3spotlight">
              <div className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-ph2d7f8ea091">
                <div className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-logofooterklrcpng"></div>
                <span className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-text201">
                  <span>
                    <span>The Kenya Law Reform Commission</span>
                    <br></br>
                    <span>has a statutory and ongoing role of</span>
                    <br></br>
                    <span>reviewing all the laws of Kenya to</span>
                    <br></br>
                    <span>ensure that it is modernized, relevant</span>
                    <br></br>
                    <span>and harmonized with the Constitution</span>
                    <br></br>
                    <span>of Kenya. KLRC has an additional</span>
                    <br></br>
                    <span>mandate of preparing new legislation</span>
                    <br></br>
                    <span>to give effect to the Constitution</span>
                  </span>
                </span>
              </div>
              <div className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-divmoduleinner2">
                <span className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-text218">
                  <span>About KLRC</span>
                </span>
                <div className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-list5">
                  <div className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-item-link16">
                    <span className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-text220">
                      
                    </span>
                    <span className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-text221">
                      <span>The Constitution of Kenya</span>
                    </span>
                  </div>
                  <div className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-item-link17">
                    <span className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-text223">
                      
                    </span>
                    <span className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-text224">
                      <span>KLRC Act, 2013 (PDF)</span>
                    </span>
                  </div>
                  <div className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-item-link18">
                    <span className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-text226">
                      
                    </span>
                    <span className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-text227">
                      <span>Strategic Plan</span>
                    </span>
                  </div>
                  <div className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-item-link19">
                    <span className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-text229">
                      
                    </span>
                    <span className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-text230">
                      <span>Staff Intranet</span>
                    </span>
                  </div>
                  <div className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-item-link20">
                    <span className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-text232">
                      
                    </span>
                    <span className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-text233">
                      <span>History and Background</span>
                    </span>
                  </div>
                  <div className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-item-link21">
                    <span className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-text235">
                      
                    </span>
                    <span className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-text236">
                      <span>Feedback Form</span>
                    </span>
                  </div>
                  <div className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-item-link22">
                    <span className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-text238">
                      
                    </span>
                    <span className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-text239">
                      <span>Report Corruption about KLRC</span>
                    </span>
                  </div>
                  <div className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-item-link23">
                    <span className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-text241">
                      
                    </span>
                    <span className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-text242">
                      <span>Lodge Complaint About KLRC</span>
                    </span>
                  </div>
                </div>
              </div>
              <div className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-divmoduleinner3">
                <span className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-text244">
                  <span>KLRC Contacts</span>
                </span>
                <div className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-list6">
                  <div className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-item">
                    <span className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-text246">
                      <span className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-text247">
                        Physical Address:
                        <span
                          dangerouslySetInnerHTML={{
                            __html: ' ',
                          }}
                        />
                      </span>
                      <span className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-text248">
                        <span>Reinsurance</span>
                        <br></br>
                        <span>Plaza, 3rd Floor, 4 Taifa Road</span>
                        <br></br>
                        <span>P.O. Box 34999-00100</span>
                        <br></br>
                        <span>NAIROBI,</span>
                        <br></br>
                        <span>Kenya. </span>
                      </span>
                      <span className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-text258">
                        Email: 
                      </span>
                      <span>info@klrc.go.ke</span>
                    </span>
                  </div>
                  <div className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-item1">
                    <span className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-text260">
                      <span className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-text261">
                        Phone:
                        <span
                          dangerouslySetInnerHTML={{
                            __html: ' ',
                          }}
                        />
                      </span>
                      <span className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-text262">
                        <span>(+254) 20 2241201,</span>
                        <br></br>
                        <span>+254799030716</span>
                      </span>
                      <span className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-text266">
                        <span>, Fax:</span>
                        <br></br>
                        <span></span>
                      </span>
                      <span>(+254)202225786</span>
                    </span>
                    <div className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-linkfacebookaccountklrcpng"></div>
                    <div className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-linktwitteraccountklrcpng"></div>
                    <div className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-linkyoutubeaccountklrcpng"></div>
                  </div>
                </div>
              </div>
              <div className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-divmoduleinner4">
                <span className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-text271">
                  <span>Newsletter Signup</span>
                </span>
                <div className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-form">
                  <div className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-divacymailingintrotext">
                    <span className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-text273">
                      <span>
                        <span>Subscribe to our newsletter for</span>
                        <br></br>
                        <span>updates on vacancies, tender</span>
                        <br></br>
                        <span>opportunities and other KLRC</span>
                        <br></br>
                        <span>updates</span>
                      </span>
                    </span>
                  </div>
                  <div className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-table-body">
                    <div className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-row-data-input">
                      <div className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-pseudo">
                        <span className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-text282">
                          <span>Name</span>
                        </span>
                      </div>
                    </div>
                    <div className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-row-data-input1">
                      <div className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-pseudo1">
                        <span className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-text284">
                          <span>E-mail</span>
                        </span>
                      </div>
                    </div>
                    <input
                      type="text"
                      placeholder="Subscribe"
                      className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-row-data-input2"
                    />
                  </div>
                  <div className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-divacymailingfinaltext">
                    <span className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-text286">
                      <span>
                        <span>We do not spam and your email</span>
                        <br></br>
                        <span>address is confidential</span>
                      </span>
                    </span>
                  </div>
                </div>
              </div>
            </div>
            <div className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-divt3copyright">
              <div className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-small">
                <span className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-text291">
                  <span className="wwwklrcgokebyhtmltodesign-fr-eversion20062023144007-text292">
                    Copyright © 2023 Kenya Law Reform Commission (KLRC). All
                    Rights Reserved. Concept by
                    <span
                      dangerouslySetInnerHTML={{
                        __html: ' ',
                      }}
                    />
                  </span>
                  <span>24i</span>
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default WwwklrcgokebyhtmltodesignFREEversion20062023144007
